
# Zaik Ticket Bot

Bot de Telegram para generar tickets personalizados de compra con productos, descuentos, totales y fotos.

### ¿Cómo usarlo?

1. Crea un repositorio nuevo en GitHub.
2. Sube estos archivos al repositorio.
3. Ve a https://render.com y crea una cuenta (si no tienes una).
4. Conecta tu cuenta de GitHub a Render.
5. En Render, selecciona “New Web Service” y elige este repositorio.
6. Render detectará el archivo `render.yaml` y configurará todo automáticamente.
7. Una vez desplegado, ve a tu bot de Telegram y escribe `/start`.

